
// GENERATED FILE DO NOT EDIT
// $ xsltproc UIDToC++.xsl Part6.xml > gdcmUIDs.h

/*=========================================================================

  Program: GDCM (Grassroots DICOM). A DICOM library

  Copyright (c) 2006-2011 Mathieu Malaterre
  All rights reserved.
  See Copyright.txt or http://gdcm.sourceforge.net/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef GDCMUIDS_H
#define GDCMUIDS_H

#include "gdcmTypes.h"

namespace gdcm
{

/**
 * \brief all known uids
 */
class GDCM_EXPORT UIDs
{
public:
  typedef enum {
uid_1_2_840_10008_1_1 = 1, // Verification SOP Class
uid_1_2_840_10008_1_2 = 2, // Implicit VR Little Endian: Default Transfer Syntax for DICOM
uid_1_2_840_10008_1_2_1 = 3, // Explicit VR Little Endian
uid_1_2_840_10008_1_2_1_98 = 4, // Encapsulated Uncompressed Explicit VR Little Endian
uid_1_2_840_10008_1_2_1_99 = 5, // Deflated Explicit VR Little Endian
uid_1_2_840_10008_1_2_2 = 6, // Explicit VR Big Endian
uid_1_2_840_10008_1_2_4_50 = 7, // JPEG Baseline (Process 1): Default Transfer Syntax for Lossy JPEG 8 Bit Image Compression
uid_1_2_840_10008_1_2_4_51 = 8, // JPEG Extended (Process 2 & 4): Default Transfer Syntax for Lossy JPEG 12 Bit Image Compression (Process 4 only)
uid_1_2_840_10008_1_2_4_52 = 9, // JPEG Extended (Process 3 & 5)
uid_1_2_840_10008_1_2_4_53 = 10, // JPEG Spectral Selection, Non-Hierarchical (Process 6 & 8)
uid_1_2_840_10008_1_2_4_54 = 11, // JPEG Spectral Selection, Non-Hierarchical (Process 7 & 9)
uid_1_2_840_10008_1_2_4_55 = 12, // JPEG Full Progression, Non-Hierarchical (Process 10 & 12)
uid_1_2_840_10008_1_2_4_56 = 13, // JPEG Full Progression, Non-Hierarchical (Process 11 & 13)
uid_1_2_840_10008_1_2_4_57 = 14, // JPEG Lossless, Non-Hierarchical (Process 14)
uid_1_2_840_10008_1_2_4_58 = 15, // JPEG Lossless, Non-Hierarchical (Process 15)
uid_1_2_840_10008_1_2_4_59 = 16, // JPEG Extended, Hierarchical (Process 16 & 18)
uid_1_2_840_10008_1_2_4_60 = 17, // JPEG Extended, Hierarchical (Process 17 & 19)
uid_1_2_840_10008_1_2_4_61 = 18, // JPEG Spectral Selection, Hierarchical (Process 20 & 22)
uid_1_2_840_10008_1_2_4_62 = 19, // JPEG Spectral Selection, Hierarchical (Process 21 & 23)
uid_1_2_840_10008_1_2_4_63 = 20, // JPEG Full Progression, Hierarchical (Process 24 & 26)
uid_1_2_840_10008_1_2_4_64 = 21, // JPEG Full Progression, Hierarchical (Process 25 & 27)
uid_1_2_840_10008_1_2_4_65 = 22, // JPEG Lossless, Hierarchical (Process 28)
uid_1_2_840_10008_1_2_4_66 = 23, // JPEG Lossless, Hierarchical (Process 29)
uid_1_2_840_10008_1_2_4_70 = 24, // JPEG Lossless, Non-Hierarchical, First-Order Prediction (Process 14 [Selection Value 1]): Default Transfer Syntax for Lossless JPEG Image Compression
uid_1_2_840_10008_1_2_4_80 = 25, // JPEG-LS Lossless Image Compression
uid_1_2_840_10008_1_2_4_81 = 26, // JPEG-LS Lossy (Near-Lossless) Image Compression
uid_1_2_840_10008_1_2_4_90 = 27, // JPEG 2000 Image Compression (Lossless Only)
uid_1_2_840_10008_1_2_4_91 = 28, // JPEG 2000 Image Compression
uid_1_2_840_10008_1_2_4_92 = 29, // JPEG 2000 Part 2 Multi-component Image Compression (Lossless Only)
uid_1_2_840_10008_1_2_4_93 = 30, // JPEG 2000 Part 2 Multi-component Image Compression
uid_1_2_840_10008_1_2_4_94 = 31, // JPIP Referenced
uid_1_2_840_10008_1_2_4_95 = 32, // JPIP Referenced Deflate
uid_1_2_840_10008_1_2_4_100 = 33, // MPEG2 Main Profile / Main Level
uid_1_2_840_10008_1_2_4_100_1 = 34, // Fragmentable MPEG2 Main Profile / Main Level
uid_1_2_840_10008_1_2_4_101 = 35, // MPEG2 Main Profile / High Level
uid_1_2_840_10008_1_2_4_101_1 = 36, // Fragmentable MPEG2 Main Profile / High Level
uid_1_2_840_10008_1_2_4_102 = 37, // MPEG-4 AVC/H.264 High Profile / Level 4.1
uid_1_2_840_10008_1_2_4_102_1 = 38, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.1
uid_1_2_840_10008_1_2_4_103 = 39, // MPEG-4 AVC/H.264 BD-compatible High Profile / Level 4.1
uid_1_2_840_10008_1_2_4_103_1 = 40, // Fragmentable MPEG-4 AVC/H.264 BD-compatible High Profile / Level 4.1
uid_1_2_840_10008_1_2_4_104 = 41, // MPEG-4 AVC/H.264 High Profile / Level 4.2 For 2D Video
uid_1_2_840_10008_1_2_4_104_1 = 42, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.2 For 2D Video
uid_1_2_840_10008_1_2_4_105 = 43, // MPEG-4 AVC/H.264 High Profile / Level 4.2 For 3D Video
uid_1_2_840_10008_1_2_4_105_1 = 44, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.2 For 3D Video
uid_1_2_840_10008_1_2_4_106 = 45, // MPEG-4 AVC/H.264 Stereo High Profile / Level 4.2
uid_1_2_840_10008_1_2_4_106_1 = 46, // Fragmentable MPEG-4 AVC/H.264 Stereo High Profile / Level 4.2
uid_1_2_840_10008_1_2_4_107 = 47, // HEVC/H.265 Main Profile / Level 5.1
uid_1_2_840_10008_1_2_4_108 = 48, // HEVC/H.265 Main 10 Profile / Level 5.1
uid_1_2_840_10008_1_2_5 = 49, // RLE Lossless
uid_1_2_840_10008_1_2_6_1 = 50, // RFC 2557 MIME encapsulation
uid_1_2_840_10008_1_2_6_2 = 51, // XML Encoding
uid_1_2_840_10008_1_2_7_1 = 52, // SMPTE ST 2110-20 Uncompressed Progressive Active Video
uid_1_2_840_10008_1_2_7_2 = 53, // SMPTE ST 2110-20 Uncompressed Interlaced Active Video
uid_1_2_840_10008_1_2_7_3 = 54, // SMPTE ST 2110-30 PCM Digital Audio
uid_1_2_840_10008_1_3_10 = 55, // Media Storage Directory Storage
uid_1_2_840_10008_1_5_1 = 56, // Hot Iron Color Palette SOP Instance
uid_1_2_840_10008_1_5_2 = 57, // PET Color Palette SOP Instance
uid_1_2_840_10008_1_5_3 = 58, // Hot Metal Blue Color Palette SOP Instance
uid_1_2_840_10008_1_5_4 = 59, // PET 20 Step Color Palette SOP Instance
uid_1_2_840_10008_1_5_5 = 60, // Spring Color Palette SOP Instance
uid_1_2_840_10008_1_5_6 = 61, // Summer Color Palette SOP Instance
uid_1_2_840_10008_1_5_7 = 62, // Fall Color Palette SOP Instance
uid_1_2_840_10008_1_5_8 = 63, // Winter Color Palette SOP Instance
uid_1_2_840_10008_1_9 = 64, // Basic Study Content Notification SOP Class
uid_1_2_840_10008_1_20 = 65, // Papyrus 3 Implicit VR Little Endian
uid_1_2_840_10008_1_20_1 = 66, // Storage Commitment Push Model SOP Class
uid_1_2_840_10008_1_20_1_1 = 67, // Storage Commitment Push Model SOP Instance
uid_1_2_840_10008_1_20_2 = 68, // Storage Commitment Pull Model SOP Class
uid_1_2_840_10008_1_20_2_1 = 69, // Storage Commitment Pull Model SOP Instance
uid_1_2_840_10008_1_40 = 70, // Procedural Event Logging SOP Class
uid_1_2_840_10008_1_40_1 = 71, // Procedural Event Logging SOP Instance
uid_1_2_840_10008_1_42 = 72, // Substance Administration Logging SOP Class
uid_1_2_840_10008_1_42_1 = 73, // Substance Administration Logging SOP Instance
uid_1_2_840_10008_2_6_1 = 74, // DICOM UID Registry
uid_1_2_840_10008_2_16_4 = 75, // DICOM Controlled Terminology
uid_1_2_840_10008_2_16_5 = 76, // Adult Mouse Anatomy Ontology
uid_1_2_840_10008_2_16_6 = 77, // Uberon Ontology
uid_1_2_840_10008_2_16_7 = 78, // Integrated Taxonomic Information System (ITIS) Taxonomic Serial Number (TSN)
uid_1_2_840_10008_2_16_8 = 79, // Mouse Genome Initiative (MGI)
uid_1_2_840_10008_2_16_9 = 80, // PubChem Compound CID
uid_1_2_840_10008_2_16_10 = 81, // Dublin Core
uid_1_2_840_10008_2_16_11 = 82, // New York University Melanoma Clinical Cooperative Group
uid_1_2_840_10008_2_16_12 = 83, // Mayo Clinic Non-radiological Images Specific Body Structure Anatomical Surface Region Guide
uid_1_2_840_10008_2_16_13 = 84, // Image Biomarker Standardisation Initiative
uid_1_2_840_10008_2_16_14 = 85, // Radiomics Ontology
uid_1_2_840_10008_2_16_15 = 86, // RadElement
uid_1_2_840_10008_2_16_16 = 87, // ICD-11
uid_1_2_840_10008_2_16_17 = 88, // Unified numbering system (UNS) for metals and alloys
uid_1_2_840_10008_2_16_18 = 89, // Research Resource Identification
uid_1_2_840_10008_3_1_1_1 = 90, // DICOM Application Context Name
uid_1_2_840_10008_3_1_2_1_1 = 91, // Detached Patient Management SOP Class
uid_1_2_840_10008_3_1_2_1_4 = 92, // Detached Patient Management Meta SOP Class
uid_1_2_840_10008_3_1_2_2_1 = 93, // Detached Visit Management SOP Class
uid_1_2_840_10008_3_1_2_3_1 = 94, // Detached Study Management SOP Class
uid_1_2_840_10008_3_1_2_3_2 = 95, // Study Component Management SOP Class
uid_1_2_840_10008_3_1_2_3_3 = 96, // Modality Performed Procedure Step SOP Class
uid_1_2_840_10008_3_1_2_3_4 = 97, // Modality Performed Procedure Step Retrieve SOP Class
uid_1_2_840_10008_3_1_2_3_5 = 98, // Modality Performed Procedure Step Notification SOP Class
uid_1_2_840_10008_3_1_2_5_1 = 99, // Detached Results Management SOP Class
uid_1_2_840_10008_3_1_2_5_4 = 100, // Detached Results Management Meta SOP Class
uid_1_2_840_10008_3_1_2_5_5 = 101, // Detached Study Management Meta SOP Class
uid_1_2_840_10008_3_1_2_6_1 = 102, // Detached Interpretation Management SOP Class
uid_1_2_840_10008_4_2 = 103, // Storage Service Class
uid_1_2_840_10008_5_1_1_1 = 104, // Basic Film Session SOP Class
uid_1_2_840_10008_5_1_1_2 = 105, // Basic Film Box SOP Class
uid_1_2_840_10008_5_1_1_4 = 106, // Basic Grayscale Image Box SOP Class
uid_1_2_840_10008_5_1_1_4_1 = 107, // Basic Color Image Box SOP Class
uid_1_2_840_10008_5_1_1_4_2 = 108, // Referenced Image Box SOP Class
uid_1_2_840_10008_5_1_1_9 = 109, // Basic Grayscale Print Management Meta SOP Class
uid_1_2_840_10008_5_1_1_9_1 = 110, // Referenced Grayscale Print Management Meta SOP Class
uid_1_2_840_10008_5_1_1_14 = 111, // Print Job SOP Class
uid_1_2_840_10008_5_1_1_15 = 112, // Basic Annotation Box SOP Class
uid_1_2_840_10008_5_1_1_16 = 113, // Printer SOP Class
uid_1_2_840_10008_5_1_1_16_376 = 114, // Printer Configuration Retrieval SOP Class
uid_1_2_840_10008_5_1_1_17 = 115, // Printer SOP Instance
uid_1_2_840_10008_5_1_1_17_376 = 116, // Printer Configuration Retrieval SOP Instance
uid_1_2_840_10008_5_1_1_18 = 117, // Basic Color Print Management Meta SOP Class
uid_1_2_840_10008_5_1_1_18_1 = 118, // Referenced Color Print Management Meta SOP Class
uid_1_2_840_10008_5_1_1_22 = 119, // VOI LUT Box SOP Class
uid_1_2_840_10008_5_1_1_23 = 120, // Presentation LUT SOP Class
uid_1_2_840_10008_5_1_1_24 = 121, // Image Overlay Box SOP Class
uid_1_2_840_10008_5_1_1_24_1 = 122, // Basic Print Image Overlay Box SOP Class
uid_1_2_840_10008_5_1_1_25 = 123, // Print Queue SOP Instance
uid_1_2_840_10008_5_1_1_26 = 124, // Print Queue Management SOP Class
uid_1_2_840_10008_5_1_1_27 = 125, // Stored Print Storage SOP Class
uid_1_2_840_10008_5_1_1_29 = 126, // Hardcopy Grayscale Image Storage SOP Class
uid_1_2_840_10008_5_1_1_30 = 127, // Hardcopy Color Image Storage SOP Class
uid_1_2_840_10008_5_1_1_31 = 128, // Pull Print Request SOP Class
uid_1_2_840_10008_5_1_1_32 = 129, // Pull Stored Print Management Meta SOP Class
uid_1_2_840_10008_5_1_1_33 = 130, // Media Creation Management SOP Class UID
uid_1_2_840_10008_5_1_1_40 = 131, // Display System SOP Class
uid_1_2_840_10008_5_1_1_40_1 = 132, // Display System SOP Instance
uid_1_2_840_10008_5_1_4_1_1_1 = 133, // Computed Radiography Image Storage
uid_1_2_840_10008_5_1_4_1_1_1_1 = 134, // Digital X-Ray Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_1_1_1 = 135, // Digital X-Ray Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_1_2 = 136, // Digital Mammography X-Ray Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_1_2_1 = 137, // Digital Mammography X-Ray Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_1_3 = 138, // Digital Intra-Oral X-Ray Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_1_3_1 = 139, // Digital Intra-Oral X-Ray Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_2 = 140, // CT Image Storage
uid_1_2_840_10008_5_1_4_1_1_2_1 = 141, // Enhanced CT Image Storage
uid_1_2_840_10008_5_1_4_1_1_2_2 = 142, // Legacy Converted Enhanced CT Image Storage
uid_1_2_840_10008_5_1_4_1_1_3 = 143, // Ultrasound Multi-frame Image Storage
uid_1_2_840_10008_5_1_4_1_1_3_1 = 144, // Ultrasound Multi-frame Image Storage
uid_1_2_840_10008_5_1_4_1_1_4 = 145, // MR Image Storage
uid_1_2_840_10008_5_1_4_1_1_4_1 = 146, // Enhanced MR Image Storage
uid_1_2_840_10008_5_1_4_1_1_4_2 = 147, // MR Spectroscopy Storage
uid_1_2_840_10008_5_1_4_1_1_4_3 = 148, // Enhanced MR Color Image Storage
uid_1_2_840_10008_5_1_4_1_1_4_4 = 149, // Legacy Converted Enhanced MR Image Storage
uid_1_2_840_10008_5_1_4_1_1_5 = 150, // Nuclear Medicine Image Storage
uid_1_2_840_10008_5_1_4_1_1_6 = 151, // Ultrasound Image Storage
uid_1_2_840_10008_5_1_4_1_1_6_1 = 152, // Ultrasound Image Storage
uid_1_2_840_10008_5_1_4_1_1_6_2 = 153, // Enhanced US Volume Storage
uid_1_2_840_10008_5_1_4_1_1_7 = 154, // Secondary Capture Image Storage
uid_1_2_840_10008_5_1_4_1_1_7_1 = 155, // Multi-frame Single Bit Secondary Capture Image Storage
uid_1_2_840_10008_5_1_4_1_1_7_2 = 156, // Multi-frame Grayscale Byte Secondary Capture Image Storage
uid_1_2_840_10008_5_1_4_1_1_7_3 = 157, // Multi-frame Grayscale Word Secondary Capture Image Storage
uid_1_2_840_10008_5_1_4_1_1_7_4 = 158, // Multi-frame True Color Secondary Capture Image Storage
uid_1_2_840_10008_5_1_4_1_1_8 = 159, // Standalone Overlay Storage
uid_1_2_840_10008_5_1_4_1_1_9 = 160, // Standalone Curve Storage
uid_1_2_840_10008_5_1_4_1_1_9_1 = 161, // Waveform Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_9_1_1 = 162, // 12-lead ECG Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_1_2 = 163, // General ECG Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_1_3 = 164, // Ambulatory ECG Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_2_1 = 165, // Hemodynamic Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_3_1 = 166, // Cardiac Electrophysiology Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_4_1 = 167, // Basic Voice Audio Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_4_2 = 168, // General Audio Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_5_1 = 169, // Arterial Pulse Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_6_1 = 170, // Respiratory Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_6_2 = 171, // Multi-channel Respiratory Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_7_1 = 172, // Routine Scalp Electroencephalogram Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_7_2 = 173, // Electromyogram Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_7_3 = 174, // Electrooculogram Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_7_4 = 175, // Sleep Electroencephalogram Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_9_8_1 = 176, // Body Position Waveform Storage
uid_1_2_840_10008_5_1_4_1_1_10 = 177, // Standalone Modality LUT Storage
uid_1_2_840_10008_5_1_4_1_1_11 = 178, // Standalone VOI LUT Storage
uid_1_2_840_10008_5_1_4_1_1_11_1 = 179, // Grayscale Softcopy Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_2 = 180, // Color Softcopy Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_3 = 181, // Pseudo-Color Softcopy Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_4 = 182, // Blending Softcopy Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_5 = 183, // XA/XRF Grayscale Softcopy Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_6 = 184, // Grayscale Planar MPR Volumetric Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_7 = 185, // Compositing Planar MPR Volumetric Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_8 = 186, // Advanced Blending Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_9 = 187, // Volume Rendering Volumetric Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_10 = 188, // Segmented Volume Rendering Volumetric Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_11_11 = 189, // Multiple Volume Rendering Volumetric Presentation State Storage
uid_1_2_840_10008_5_1_4_1_1_12_1 = 190, // X-Ray Angiographic Image Storage
uid_1_2_840_10008_5_1_4_1_1_12_1_1 = 191, // Enhanced XA Image Storage
uid_1_2_840_10008_5_1_4_1_1_12_2 = 192, // X-Ray Radiofluoroscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_12_2_1 = 193, // Enhanced XRF Image Storage
uid_1_2_840_10008_5_1_4_1_1_12_3 = 194, // X-Ray Angiographic Bi-Plane Image Storage
uid_1_2_840_10008_5_1_4_1_1_12_77 = 195, // 
uid_1_2_840_10008_5_1_4_1_1_13_1_1 = 196, // X-Ray 3D Angiographic Image Storage
uid_1_2_840_10008_5_1_4_1_1_13_1_2 = 197, // X-Ray 3D Craniofacial Image Storage
uid_1_2_840_10008_5_1_4_1_1_13_1_3 = 198, // Breast Tomosynthesis Image Storage
uid_1_2_840_10008_5_1_4_1_1_13_1_4 = 199, // Breast Projection X-Ray Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_13_1_5 = 200, // Breast Projection X-Ray Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_14_1 = 201, // Intravascular Optical Coherence Tomography Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_14_2 = 202, // Intravascular Optical Coherence Tomography Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_20 = 203, // Nuclear Medicine Image Storage
uid_1_2_840_10008_5_1_4_1_1_30 = 204, // Parametric Map Storage
uid_1_2_840_10008_5_1_4_1_1_40 = 205, // 
uid_1_2_840_10008_5_1_4_1_1_66 = 206, // Raw Data Storage
uid_1_2_840_10008_5_1_4_1_1_66_1 = 207, // Spatial Registration Storage
uid_1_2_840_10008_5_1_4_1_1_66_2 = 208, // Spatial Fiducials Storage
uid_1_2_840_10008_5_1_4_1_1_66_3 = 209, // Deformable Spatial Registration Storage
uid_1_2_840_10008_5_1_4_1_1_66_4 = 210, // Segmentation Storage
uid_1_2_840_10008_5_1_4_1_1_66_5 = 211, // Surface Segmentation Storage
uid_1_2_840_10008_5_1_4_1_1_66_6 = 212, // Tractography Results Storage
uid_1_2_840_10008_5_1_4_1_1_67 = 213, // Real World Value Mapping Storage
uid_1_2_840_10008_5_1_4_1_1_68_1 = 214, // Surface Scan Mesh Storage
uid_1_2_840_10008_5_1_4_1_1_68_2 = 215, // Surface Scan Point Cloud Storage
uid_1_2_840_10008_5_1_4_1_1_77_1 = 216, // VL Image Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_77_2 = 217, // VL Multi-frame Image Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_77_1_1 = 218, // VL Endoscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_1_1 = 219, // Video Endoscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_2 = 220, // VL Microscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_2_1 = 221, // Video Microscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_3 = 222, // VL Slide-Coordinates Microscopic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_4 = 223, // VL Photographic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_4_1 = 224, // Video Photographic Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_1 = 225, // Ophthalmic Photography 8 Bit Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_2 = 226, // Ophthalmic Photography 16 Bit Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_3 = 227, // Stereometric Relationship Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_4 = 228, // Ophthalmic Tomography Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_5 = 229, // Wide Field Ophthalmic Photography Stereographic Projection Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_6 = 230, // Wide Field Ophthalmic Photography 3D Coordinates Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_7 = 231, // Ophthalmic Optical Coherence Tomography En Face Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_5_8 = 232, // Ophthalmic Optical Coherence Tomography B-scan Volume Analysis Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_6 = 233, // VL Whole Slide Microscopy Image Storage
uid_1_2_840_10008_5_1_4_1_1_77_1_7 = 234, // Dermoscopic Photography Image Storage
uid_1_2_840_10008_5_1_4_1_1_78_1 = 235, // Lensometry Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_2 = 236, // Autorefraction Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_3 = 237, // Keratometry Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_4 = 238, // Subjective Refraction Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_5 = 239, // Visual Acuity Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_6 = 240, // Spectacle Prescription Report Storage
uid_1_2_840_10008_5_1_4_1_1_78_7 = 241, // Ophthalmic Axial Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_78_8 = 242, // Intraocular Lens Calculations Storage
uid_1_2_840_10008_5_1_4_1_1_79_1 = 243, // Macular Grid Thickness and Volume Report Storage
uid_1_2_840_10008_5_1_4_1_1_80_1 = 244, // Ophthalmic Visual Field Static Perimetry Measurements Storage
uid_1_2_840_10008_5_1_4_1_1_81_1 = 245, // Ophthalmic Thickness Map Storage
uid_1_2_840_10008_5_1_4_1_1_82_1 = 246, // Corneal Topography Map Storage
uid_1_2_840_10008_5_1_4_1_1_88_1 = 247, // Text SR Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_88_2 = 248, // Audio SR Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_88_3 = 249, // Detail SR Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_88_4 = 250, // Comprehensive SR Storage - Trial
uid_1_2_840_10008_5_1_4_1_1_88_11 = 251, // Basic Text SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_22 = 252, // Enhanced SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_33 = 253, // Comprehensive SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_34 = 254, // Comprehensive 3D SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_35 = 255, // Extensible SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_40 = 256, // Procedure Log Storage
uid_1_2_840_10008_5_1_4_1_1_88_50 = 257, // Mammography CAD SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_59 = 258, // Key Object Selection Document Storage
uid_1_2_840_10008_5_1_4_1_1_88_65 = 259, // Chest CAD SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_67 = 260, // X-Ray Radiation Dose SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_68 = 261, // Radiopharmaceutical Radiation Dose SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_69 = 262, // Colon CAD SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_70 = 263, // Implantation Plan SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_71 = 264, // Acquisition Context SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_72 = 265, // Simplified Adult Echo SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_73 = 266, // Patient Radiation Dose SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_74 = 267, // Planned Imaging Agent Administration SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_75 = 268, // Performed Imaging Agent Administration SR Storage
uid_1_2_840_10008_5_1_4_1_1_88_76 = 269, // Enhanced X-Ray Radiation Dose SR Storage
uid_1_2_840_10008_5_1_4_1_1_90_1 = 270, // Content Assessment Results Storage
uid_1_2_840_10008_5_1_4_1_1_91_1 = 271, // Microscopy Bulk Simple Annotations Storage
uid_1_2_840_10008_5_1_4_1_1_104_1 = 272, // Encapsulated PDF Storage
uid_1_2_840_10008_5_1_4_1_1_104_2 = 273, // Encapsulated CDA Storage
uid_1_2_840_10008_5_1_4_1_1_104_3 = 274, // Encapsulated STL Storage
uid_1_2_840_10008_5_1_4_1_1_104_4 = 275, // Encapsulated OBJ Storage
uid_1_2_840_10008_5_1_4_1_1_104_5 = 276, // Encapsulated MTL Storage
uid_1_2_840_10008_5_1_4_1_1_128 = 277, // Positron Emission Tomography Image Storage
uid_1_2_840_10008_5_1_4_1_1_128_1 = 278, // Legacy Converted Enhanced PET Image Storage
uid_1_2_840_10008_5_1_4_1_1_129 = 279, // Standalone PET Curve Storage
uid_1_2_840_10008_5_1_4_1_1_130 = 280, // Enhanced PET Image Storage
uid_1_2_840_10008_5_1_4_1_1_131 = 281, // Basic Structured Display Storage
uid_1_2_840_10008_5_1_4_1_1_200_1 = 282, // CT Defined Procedure Protocol Storage
uid_1_2_840_10008_5_1_4_1_1_200_2 = 283, // CT Performed Procedure Protocol Storage
uid_1_2_840_10008_5_1_4_1_1_200_3 = 284, // Protocol Approval Storage
uid_1_2_840_10008_5_1_4_1_1_200_4 = 285, // Protocol Approval Information Model - FIND
uid_1_2_840_10008_5_1_4_1_1_200_5 = 286, // Protocol Approval Information Model - MOVE
uid_1_2_840_10008_5_1_4_1_1_200_6 = 287, // Protocol Approval Information Model - GET
uid_1_2_840_10008_5_1_4_1_1_200_7 = 288, // XA Defined Procedure Protocol Storage
uid_1_2_840_10008_5_1_4_1_1_200_8 = 289, // XA Performed Procedure Protocol Storage
uid_1_2_840_10008_5_1_4_1_1_201_1 = 290, // Inventory Storage
uid_1_2_840_10008_5_1_4_1_1_201_2 = 291, // Inventory - FIND
uid_1_2_840_10008_5_1_4_1_1_201_3 = 292, // Inventory - MOVE
uid_1_2_840_10008_5_1_4_1_1_201_4 = 293, // Inventory - GET
uid_1_2_840_10008_5_1_4_1_1_201_5 = 294, // Inventory Creation
uid_1_2_840_10008_5_1_4_1_1_201_6 = 295, // Repository Query
uid_1_2_840_10008_5_1_4_1_1_201_1_1 = 296, // Storage Management SOP Instance
uid_1_2_840_10008_5_1_4_1_1_481_1 = 297, // RT Image Storage
uid_1_2_840_10008_5_1_4_1_1_481_2 = 298, // RT Dose Storage
uid_1_2_840_10008_5_1_4_1_1_481_3 = 299, // RT Structure Set Storage
uid_1_2_840_10008_5_1_4_1_1_481_4 = 300, // RT Beams Treatment Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_5 = 301, // RT Plan Storage
uid_1_2_840_10008_5_1_4_1_1_481_6 = 302, // RT Brachy Treatment Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_7 = 303, // RT Treatment Summary Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_8 = 304, // RT Ion Plan Storage
uid_1_2_840_10008_5_1_4_1_1_481_9 = 305, // RT Ion Beams Treatment Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_10 = 306, // RT Physician Intent Storage
uid_1_2_840_10008_5_1_4_1_1_481_11 = 307, // RT Segment Annotation Storage
uid_1_2_840_10008_5_1_4_1_1_481_12 = 308, // RT Radiation Set Storage
uid_1_2_840_10008_5_1_4_1_1_481_13 = 309, // C-Arm Photon-Electron Radiation Storage
uid_1_2_840_10008_5_1_4_1_1_481_14 = 310, // Tomotherapeutic Radiation Storage
uid_1_2_840_10008_5_1_4_1_1_481_15 = 311, // Robotic-Arm Radiation Storage
uid_1_2_840_10008_5_1_4_1_1_481_16 = 312, // RT Radiation Record Set Storage
uid_1_2_840_10008_5_1_4_1_1_481_17 = 313, // RT Radiation Salvage Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_18 = 314, // Tomotherapeutic Radiation Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_19 = 315, // C-Arm Photon-Electron Radiation Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_20 = 316, // Robotic Radiation Record Storage
uid_1_2_840_10008_5_1_4_1_1_481_21 = 317, // RT Radiation Set Delivery Instruction Storage
uid_1_2_840_10008_5_1_4_1_1_481_22 = 318, // RT Treatment Preparation Storage
uid_1_2_840_10008_5_1_4_1_1_501_1 = 319, // DICOS CT Image Storage
uid_1_2_840_10008_5_1_4_1_1_501_2_1 = 320, // DICOS Digital X-Ray Image Storage - For Presentation
uid_1_2_840_10008_5_1_4_1_1_501_2_2 = 321, // DICOS Digital X-Ray Image Storage - For Processing
uid_1_2_840_10008_5_1_4_1_1_501_3 = 322, // DICOS Threat Detection Report Storage
uid_1_2_840_10008_5_1_4_1_1_501_4 = 323, // DICOS 2D AIT Storage
uid_1_2_840_10008_5_1_4_1_1_501_5 = 324, // DICOS 3D AIT Storage
uid_1_2_840_10008_5_1_4_1_1_501_6 = 325, // DICOS Quadrupole Resonance (QR) Storage
uid_1_2_840_10008_5_1_4_1_1_601_1 = 326, // Eddy Current Image Storage
uid_1_2_840_10008_5_1_4_1_1_601_2 = 327, // Eddy Current Multi-frame Image Storage
uid_1_2_840_10008_5_1_4_1_2_1_1 = 328, // Patient Root Query/Retrieve Information Model - FIND
uid_1_2_840_10008_5_1_4_1_2_1_2 = 329, // Patient Root Query/Retrieve Information Model - MOVE
uid_1_2_840_10008_5_1_4_1_2_1_3 = 330, // Patient Root Query/Retrieve Information Model - GET
uid_1_2_840_10008_5_1_4_1_2_2_1 = 331, // Study Root Query/Retrieve Information Model - FIND
uid_1_2_840_10008_5_1_4_1_2_2_2 = 332, // Study Root Query/Retrieve Information Model - MOVE
uid_1_2_840_10008_5_1_4_1_2_2_3 = 333, // Study Root Query/Retrieve Information Model - GET
uid_1_2_840_10008_5_1_4_1_2_3_1 = 334, // Patient/Study Only Query/Retrieve Information Model - FIND
uid_1_2_840_10008_5_1_4_1_2_3_2 = 335, // Patient/Study Only Query/Retrieve Information Model - MOVE
uid_1_2_840_10008_5_1_4_1_2_3_3 = 336, // Patient/Study Only Query/Retrieve Information Model - GET
uid_1_2_840_10008_5_1_4_1_2_4_2 = 337, // Composite Instance Root Retrieve - MOVE
uid_1_2_840_10008_5_1_4_1_2_4_3 = 338, // Composite Instance Root Retrieve - GET
uid_1_2_840_10008_5_1_4_1_2_5_3 = 339, // Composite Instance Retrieve Without Bulk Data - GET
uid_1_2_840_10008_5_1_4_20_1 = 340, // Defined Procedure Protocol Information Model - FIND
uid_1_2_840_10008_5_1_4_20_2 = 341, // Defined Procedure Protocol Information Model - MOVE
uid_1_2_840_10008_5_1_4_20_3 = 342, // Defined Procedure Protocol Information Model - GET
uid_1_2_840_10008_5_1_4_31 = 343, // Modality Worklist Information Model - FIND
uid_1_2_840_10008_5_1_4_32 = 344, // General Purpose Worklist Management Meta SOP Class
uid_1_2_840_10008_5_1_4_32_1 = 345, // General Purpose Worklist Information Model - FIND
uid_1_2_840_10008_5_1_4_32_2 = 346, // General Purpose Scheduled Procedure Step SOP Class
uid_1_2_840_10008_5_1_4_32_3 = 347, // General Purpose Performed Procedure Step SOP Class
uid_1_2_840_10008_5_1_4_33 = 348, // Instance Availability Notification SOP Class
uid_1_2_840_10008_5_1_4_34_1 = 349, // RT Beams Delivery Instruction Storage - Trial
uid_1_2_840_10008_5_1_4_34_2 = 350, // RT Conventional Machine Verification - Trial
uid_1_2_840_10008_5_1_4_34_3 = 351, // RT Ion Machine Verification - Trial
uid_1_2_840_10008_5_1_4_34_4 = 352, // Unified Worklist and Procedure Step Service Class - Trial
uid_1_2_840_10008_5_1_4_34_4_1 = 353, // Unified Procedure Step - Push SOP Class - Trial
uid_1_2_840_10008_5_1_4_34_4_2 = 354, // Unified Procedure Step - Watch SOP Class - Trial
uid_1_2_840_10008_5_1_4_34_4_3 = 355, // Unified Procedure Step - Pull SOP Class - Trial
uid_1_2_840_10008_5_1_4_34_4_4 = 356, // Unified Procedure Step - Event SOP Class - Trial
uid_1_2_840_10008_5_1_4_34_5 = 357, // UPS Global Subscription SOP Instance
uid_1_2_840_10008_5_1_4_34_5_1 = 358, // UPS Filtered Global Subscription SOP Instance
uid_1_2_840_10008_5_1_4_34_6 = 359, // Unified Worklist and Procedure Step Service Class
uid_1_2_840_10008_5_1_4_34_6_1 = 360, // Unified Procedure Step - Push SOP Class
uid_1_2_840_10008_5_1_4_34_6_2 = 361, // Unified Procedure Step - Watch SOP Class
uid_1_2_840_10008_5_1_4_34_6_3 = 362, // Unified Procedure Step - Pull SOP Class
uid_1_2_840_10008_5_1_4_34_6_4 = 363, // Unified Procedure Step - Event SOP Class
uid_1_2_840_10008_5_1_4_34_6_5 = 364, // Unified Procedure Step - Query SOP Class
uid_1_2_840_10008_5_1_4_34_7 = 365, // RT Beams Delivery Instruction Storage
uid_1_2_840_10008_5_1_4_34_8 = 366, // RT Conventional Machine Verification
uid_1_2_840_10008_5_1_4_34_9 = 367, // RT Ion Machine Verification
uid_1_2_840_10008_5_1_4_34_10 = 368, // RT Brachy Application Setup Delivery Instruction Storage
uid_1_2_840_10008_5_1_4_37_1 = 369, // General Relevant Patient Information Query
uid_1_2_840_10008_5_1_4_37_2 = 370, // Breast Imaging Relevant Patient Information Query
uid_1_2_840_10008_5_1_4_37_3 = 371, // Cardiac Relevant Patient Information Query
uid_1_2_840_10008_5_1_4_38_1 = 372, // Hanging Protocol Storage
uid_1_2_840_10008_5_1_4_38_2 = 373, // Hanging Protocol Information Model - FIND
uid_1_2_840_10008_5_1_4_38_3 = 374, // Hanging Protocol Information Model - MOVE
uid_1_2_840_10008_5_1_4_38_4 = 375, // Hanging Protocol Information Model - GET
uid_1_2_840_10008_5_1_4_39_1 = 376, // Color Palette Storage
uid_1_2_840_10008_5_1_4_39_2 = 377, // Color Palette Query/Retrieve Information Model - FIND
uid_1_2_840_10008_5_1_4_39_3 = 378, // Color Palette Query/Retrieve Information Model - MOVE
uid_1_2_840_10008_5_1_4_39_4 = 379, // Color Palette Query/Retrieve Information Model - GET
uid_1_2_840_10008_5_1_4_41 = 380, // Product Characteristics Query SOP Class
uid_1_2_840_10008_5_1_4_42 = 381, // Substance Approval Query SOP Class
uid_1_2_840_10008_5_1_4_43_1 = 382, // Generic Implant Template Storage
uid_1_2_840_10008_5_1_4_43_2 = 383, // Generic Implant Template Information Model - FIND
uid_1_2_840_10008_5_1_4_43_3 = 384, // Generic Implant Template Information Model - MOVE
uid_1_2_840_10008_5_1_4_43_4 = 385, // Generic Implant Template Information Model - GET
uid_1_2_840_10008_5_1_4_44_1 = 386, // Implant Assembly Template Storage
uid_1_2_840_10008_5_1_4_44_2 = 387, // Implant Assembly Template Information Model - FIND
uid_1_2_840_10008_5_1_4_44_3 = 388, // Implant Assembly Template Information Model - MOVE
uid_1_2_840_10008_5_1_4_44_4 = 389, // Implant Assembly Template Information Model - GET
uid_1_2_840_10008_5_1_4_45_1 = 390, // Implant Template Group Storage
uid_1_2_840_10008_5_1_4_45_2 = 391, // Implant Template Group Information Model - FIND
uid_1_2_840_10008_5_1_4_45_3 = 392, // Implant Template Group Information Model - MOVE
uid_1_2_840_10008_5_1_4_45_4 = 393, // Implant Template Group Information Model - GET
uid_1_2_840_10008_7_1_1 = 394, // Native DICOM Model
uid_1_2_840_10008_7_1_2 = 395, // Abstract Multi-Dimensional Image Model
uid_1_2_840_10008_8_1_1 = 396, // DICOM Content Mapping Resource
uid_1_2_840_10008_10_1 = 397, // Video Endoscopic Image Real-Time Communication
uid_1_2_840_10008_10_2 = 398, // Video Photographic Image Real-Time Communication
uid_1_2_840_10008_10_3 = 399, // Audio Waveform Real-Time Communication
uid_1_2_840_10008_10_4 = 400, // Rendition Selection Document Real-Time Communication
uid_1_2_840_10008_15_0_3_1 = 401, // dicomDeviceName
uid_1_2_840_10008_15_0_3_2 = 402, // dicomDescription
uid_1_2_840_10008_15_0_3_3 = 403, // dicomManufacturer
uid_1_2_840_10008_15_0_3_4 = 404, // dicomManufacturerModelName
uid_1_2_840_10008_15_0_3_5 = 405, // dicomSoftwareVersion
uid_1_2_840_10008_15_0_3_6 = 406, // dicomVendorData
uid_1_2_840_10008_15_0_3_7 = 407, // dicomAETitle
uid_1_2_840_10008_15_0_3_8 = 408, // dicomNetworkConnectionReference
uid_1_2_840_10008_15_0_3_9 = 409, // dicomApplicationCluster
uid_1_2_840_10008_15_0_3_10 = 410, // dicomAssociationInitiator
uid_1_2_840_10008_15_0_3_11 = 411, // dicomAssociationAcceptor
uid_1_2_840_10008_15_0_3_12 = 412, // dicomHostname
uid_1_2_840_10008_15_0_3_13 = 413, // dicomPort
uid_1_2_840_10008_15_0_3_14 = 414, // dicomSOPClass
uid_1_2_840_10008_15_0_3_15 = 415, // dicomTransferRole
uid_1_2_840_10008_15_0_3_16 = 416, // dicomTransferSyntax
uid_1_2_840_10008_15_0_3_17 = 417, // dicomPrimaryDeviceType
uid_1_2_840_10008_15_0_3_18 = 418, // dicomRelatedDeviceReference
uid_1_2_840_10008_15_0_3_19 = 419, // dicomPreferredCalledAETitle
uid_1_2_840_10008_15_0_3_20 = 420, // dicomTLSCyphersuite
uid_1_2_840_10008_15_0_3_21 = 421, // dicomAuthorizedNodeCertificateReference
uid_1_2_840_10008_15_0_3_22 = 422, // dicomThisNodeCertificateReference
uid_1_2_840_10008_15_0_3_23 = 423, // dicomInstalled
uid_1_2_840_10008_15_0_3_24 = 424, // dicomStationName
uid_1_2_840_10008_15_0_3_25 = 425, // dicomDeviceSerialNumber
uid_1_2_840_10008_15_0_3_26 = 426, // dicomInstitutionName
uid_1_2_840_10008_15_0_3_27 = 427, // dicomInstitutionAddress
uid_1_2_840_10008_15_0_3_28 = 428, // dicomInstitutionDepartmentName
uid_1_2_840_10008_15_0_3_29 = 429, // dicomIssuerOfPatientID
uid_1_2_840_10008_15_0_3_30 = 430, // dicomPreferredCallingAETitle
uid_1_2_840_10008_15_0_3_31 = 431, // dicomSupportedCharacterSet
uid_1_2_840_10008_15_0_4_1 = 432, // dicomConfigurationRoot
uid_1_2_840_10008_15_0_4_2 = 433, // dicomDevicesRoot
uid_1_2_840_10008_15_0_4_3 = 434, // dicomUniqueAETitlesRegistryRoot
uid_1_2_840_10008_15_0_4_4 = 435, // dicomDevice
uid_1_2_840_10008_15_0_4_5 = 436, // dicomNetworkAE
uid_1_2_840_10008_15_0_4_6 = 437, // dicomNetworkConnection
uid_1_2_840_10008_15_0_4_7 = 438, // dicomUniqueAETitle
uid_1_2_840_10008_15_0_4_8 = 439, // dicomTransferCapability
uid_1_2_840_10008_15_1_1 = 440, // Universal Coordinated Time
frameref_1_2_840_10008_1_4_1_1 = 441, // Talairach Brain Atlas Frame of Reference
frameref_1_2_840_10008_1_4_1_2 = 442, // SPM2 T1 Frame of Reference
frameref_1_2_840_10008_1_4_1_3 = 443, // SPM2 T2 Frame of Reference
frameref_1_2_840_10008_1_4_1_4 = 444, // SPM2 PD Frame of Reference
frameref_1_2_840_10008_1_4_1_5 = 445, // SPM2 EPI Frame of Reference
frameref_1_2_840_10008_1_4_1_6 = 446, // SPM2 FIL T1 Frame of Reference
frameref_1_2_840_10008_1_4_1_7 = 447, // SPM2 PET Frame of Reference
frameref_1_2_840_10008_1_4_1_8 = 448, // SPM2 TRANSM Frame of Reference
frameref_1_2_840_10008_1_4_1_9 = 449, // SPM2 SPECT Frame of Reference
frameref_1_2_840_10008_1_4_1_10 = 450, // SPM2 GRAY Frame of Reference
frameref_1_2_840_10008_1_4_1_11 = 451, // SPM2 WHITE Frame of Reference
frameref_1_2_840_10008_1_4_1_12 = 452, // SPM2 CSF Frame of Reference
frameref_1_2_840_10008_1_4_1_13 = 453, // SPM2 BRAINMASK Frame of Reference
frameref_1_2_840_10008_1_4_1_14 = 454, // SPM2 AVG305T1 Frame of Reference
frameref_1_2_840_10008_1_4_1_15 = 455, // SPM2 AVG152T1 Frame of Reference
frameref_1_2_840_10008_1_4_1_16 = 456, // SPM2 AVG152T2 Frame of Reference
frameref_1_2_840_10008_1_4_1_17 = 457, // SPM2 AVG152PD Frame of Reference
frameref_1_2_840_10008_1_4_1_18 = 458, // SPM2 SINGLESUBJT1 Frame of Reference
frameref_1_2_840_10008_1_4_2_1 = 459, // ICBM 452 T1 Frame of Reference
frameref_1_2_840_10008_1_4_2_2 = 460, // ICBM Single Subject MRI Frame of Reference
frameref_1_2_840_10008_1_4_3_1 = 461, // IEC 61217 Fixed Coordinate System Frame of Reference
frameref_1_2_840_10008_1_4_3_2 = 462, // Standard Robotic-Arm Coordinate System Frame of Reference
frameref_1_2_840_10008_1_4_3_3 = 463, // IEC 61217 Table Top Coordinate System Frame of Reference
frameref_1_2_840_10008_1_4_4_1 = 464, // SRI24 Frame of Reference
frameref_1_2_840_10008_1_4_5_1 = 465, // Colin27 Frame of Reference
frameref_1_2_840_10008_1_4_6_1 = 466, // LPBA40/AIR Frame of Reference
frameref_1_2_840_10008_1_4_6_2 = 467, // LPBA40/FLIRT Frame of Reference
frameref_1_2_840_10008_1_4_6_3 = 468, // LPBA40/SPM5 Frame of Reference

/////////////////////////////////////////
//
// Optionally private UIDs
//
#if 0
uid_1_2_840_113619_4_2,
uid_1_2_840_113619_4_3,
uid_1_3_12_2_1107_5_9_1,
uid_1_2_840_113619_4_26,
uid_1_2_840_113619_4_30,
uid_2_16_840_1_113709_1_5_1,
uid_2_16_840_1_113709_1_2_2,
uid_1_2_840_113543_6_6_1_3_10002,
uid_1_2_392_200036_9116_7_8_1_1_1,
uid_1_2_392_200036_9125_1_1_2,
uid_1_2_840_113619_4_27,
uid_1_3_46_670589_11_0_0_12_1,
uid_1_3_46_670589_11_0_0_12_2,
uid_1_3_46_670589_11_0_0_12_4,
uid_1_3_46_670589_2_3_1_1,
uid_1_3_46_670589_2_4_1_1,
uid_1_3_46_670589_2_5_1_1,
uid_1_3_46_670589_5_0_1,
uid_1_3_46_670589_5_0_1_1,
uid_1_3_46_670589_5_0_10,
uid_1_3_46_670589_5_0_11,
uid_1_3_46_670589_5_0_11_1,
uid_1_3_46_670589_5_0_12,
uid_1_3_46_670589_5_0_13,
uid_1_3_46_670589_5_0_14,
uid_1_3_46_670589_5_0_2,
uid_1_3_46_670589_5_0_2_1,
uid_1_3_46_670589_5_0_3,
uid_1_3_46_670589_5_0_3_1,
uid_1_3_46_670589_5_0_4,
uid_1_3_46_670589_5_0_7,
uid_1_3_46_670589_5_0_8,
uid_1_3_46_670589_5_0_9,
uid_1_2_752_24_3_7_6,
uid_1_2_752_24_3_7_7,
uid_1_2_840_113619_5_2,
uid_1_3_46_670589_33_1_4_1
#endif
//
//
/////////////////////////////////////////

} TSType;
  typedef enum {
VerificationSOPClass = 1, // Verification SOP Class
ImplicitVRLittleEndianDefaultTransferSyntaxforDICOM = 2, // Implicit VR Little Endian: Default Transfer Syntax for DICOM
ExplicitVRLittleEndian = 3, // Explicit VR Little Endian
EncapsulatedUncompressedExplicitVRLittleEndian = 4, // Encapsulated Uncompressed Explicit VR Little Endian
DeflatedExplicitVRLittleEndian = 5, // Deflated Explicit VR Little Endian
ExplicitVRBigEndianRetired = 6, // Explicit VR Big Endian
JPEGBaselineProcess1DefaultTransferSyntaxforLossyJPEG8BitImageCompression = 7, // JPEG Baseline (Process 1): Default Transfer Syntax for Lossy JPEG 8 Bit Image Compression
JPEGExtendedProcess24DefaultTransferSyntaxforLossyJPEG12BitImageCompressionProcess4only = 8, // JPEG Extended (Process 2 & 4): Default Transfer Syntax for Lossy JPEG 12 Bit Image Compression (Process 4 only)
JPEGExtendedProcess35Retired = 9, // JPEG Extended (Process 3 & 5)
JPEGSpectralSelectionNonHierarchicalProcess68Retired = 10, // JPEG Spectral Selection, Non-Hierarchical (Process 6 & 8)
JPEGSpectralSelectionNonHierarchicalProcess79Retired = 11, // JPEG Spectral Selection, Non-Hierarchical (Process 7 & 9)
JPEGFullProgressionNonHierarchicalProcess1012Retired = 12, // JPEG Full Progression, Non-Hierarchical (Process 10 & 12)
JPEGFullProgressionNonHierarchicalProcess1113Retired = 13, // JPEG Full Progression, Non-Hierarchical (Process 11 & 13)
JPEGLosslessNonHierarchicalProcess14 = 14, // JPEG Lossless, Non-Hierarchical (Process 14)
JPEGLosslessNonHierarchicalProcess15Retired = 15, // JPEG Lossless, Non-Hierarchical (Process 15)
JPEGExtendedHierarchicalProcess1618Retired = 16, // JPEG Extended, Hierarchical (Process 16 & 18)
JPEGExtendedHierarchicalProcess1719Retired = 17, // JPEG Extended, Hierarchical (Process 17 & 19)
JPEGSpectralSelectionHierarchicalProcess2022Retired = 18, // JPEG Spectral Selection, Hierarchical (Process 20 & 22)
JPEGSpectralSelectionHierarchicalProcess2123Retired = 19, // JPEG Spectral Selection, Hierarchical (Process 21 & 23)
JPEGFullProgressionHierarchicalProcess2426Retired = 20, // JPEG Full Progression, Hierarchical (Process 24 & 26)
JPEGFullProgressionHierarchicalProcess2527Retired = 21, // JPEG Full Progression, Hierarchical (Process 25 & 27)
JPEGLosslessHierarchicalProcess28Retired = 22, // JPEG Lossless, Hierarchical (Process 28)
JPEGLosslessHierarchicalProcess29Retired = 23, // JPEG Lossless, Hierarchical (Process 29)
JPEGLosslessNonHierarchicalFirstOrderPredictionProcess14SelectionValue1DefaultTransferSyntaxforLosslessJPEGImageCompression = 24, // JPEG Lossless, Non-Hierarchical, First-Order Prediction (Process 14 [Selection Value 1]): Default Transfer Syntax for Lossless JPEG Image Compression
JPEGLSLosslessImageCompression = 25, // JPEG-LS Lossless Image Compression
JPEGLSLossyNearLosslessImageCompression = 26, // JPEG-LS Lossy (Near-Lossless) Image Compression
JPEG2000ImageCompressionLosslessOnly = 27, // JPEG 2000 Image Compression (Lossless Only)
JPEG2000ImageCompression = 28, // JPEG 2000 Image Compression
JPEG2000Part2MulticomponentImageCompressionLosslessOnly = 29, // JPEG 2000 Part 2 Multi-component Image Compression (Lossless Only)
JPEG2000Part2MulticomponentImageCompression = 30, // JPEG 2000 Part 2 Multi-component Image Compression
JPIPReferenced = 31, // JPIP Referenced
JPIPReferencedDeflate = 32, // JPIP Referenced Deflate
MPEG2MainProfileMainLevel = 33, // MPEG2 Main Profile / Main Level
FragmentableMPEG2MainProfileMainLevel = 34, // Fragmentable MPEG2 Main Profile / Main Level
MPEG2MainProfileHighLevel = 35, // MPEG2 Main Profile / High Level
FragmentableMPEG2MainProfileHighLevel = 36, // Fragmentable MPEG2 Main Profile / High Level
MPEG4AVCH264HighProfileLevel41 = 37, // MPEG-4 AVC/H.264 High Profile / Level 4.1
FragmentableMPEG4AVCH264HighProfileLevel41 = 38, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.1
MPEG4AVCH264BDcompatibleHighProfileLevel41 = 39, // MPEG-4 AVC/H.264 BD-compatible High Profile / Level 4.1
FragmentableMPEG4AVCH264BDcompatibleHighProfileLevel41 = 40, // Fragmentable MPEG-4 AVC/H.264 BD-compatible High Profile / Level 4.1
MPEG4AVCH264HighProfileLevel42For2DVideo = 41, // MPEG-4 AVC/H.264 High Profile / Level 4.2 For 2D Video
FragmentableMPEG4AVCH264HighProfileLevel42For2DVideo = 42, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.2 For 2D Video
MPEG4AVCH264HighProfileLevel42For3DVideo = 43, // MPEG-4 AVC/H.264 High Profile / Level 4.2 For 3D Video
FragmentableMPEG4AVCH264HighProfileLevel42For3DVideo = 44, // Fragmentable MPEG-4 AVC/H.264 High Profile / Level 4.2 For 3D Video
MPEG4AVCH264StereoHighProfileLevel42 = 45, // MPEG-4 AVC/H.264 Stereo High Profile / Level 4.2
FragmentableMPEG4AVCH264StereoHighProfileLevel42 = 46, // Fragmentable MPEG-4 AVC/H.264 Stereo High Profile / Level 4.2
HEVCH265MainProfileLevel51 = 47, // HEVC/H.265 Main Profile / Level 5.1
HEVCH265Main10ProfileLevel51 = 48, // HEVC/H.265 Main 10 Profile / Level 5.1
RLELossless = 49, // RLE Lossless
RFC2557MIMEencapsulationRetired = 50, // RFC 2557 MIME encapsulation
XMLEncodingRetired = 51, // XML Encoding
SMPTEST211020UncompressedProgressiveActiveVideo = 52, // SMPTE ST 2110-20 Uncompressed Progressive Active Video
SMPTEST211020UncompressedInterlacedActiveVideo = 53, // SMPTE ST 2110-20 Uncompressed Interlaced Active Video
SMPTEST211030PCMDigitalAudio = 54, // SMPTE ST 2110-30 PCM Digital Audio
MediaStorageDirectoryStorage = 55, // Media Storage Directory Storage
HotIronColorPaletteSOPInstance = 56, // Hot Iron Color Palette SOP Instance
PETColorPaletteSOPInstance = 57, // PET Color Palette SOP Instance
HotMetalBlueColorPaletteSOPInstance = 58, // Hot Metal Blue Color Palette SOP Instance
PET20StepColorPaletteSOPInstance = 59, // PET 20 Step Color Palette SOP Instance
SpringColorPaletteSOPInstance = 60, // Spring Color Palette SOP Instance
SummerColorPaletteSOPInstance = 61, // Summer Color Palette SOP Instance
FallColorPaletteSOPInstance = 62, // Fall Color Palette SOP Instance
WinterColorPaletteSOPInstance = 63, // Winter Color Palette SOP Instance
BasicStudyContentNotificationSOPClassRetired = 64, // Basic Study Content Notification SOP Class
Papyrus3ImplicitVRLittleEndianRetired = 65, // Papyrus 3 Implicit VR Little Endian
StorageCommitmentPushModelSOPClass = 66, // Storage Commitment Push Model SOP Class
StorageCommitmentPushModelSOPInstance = 67, // Storage Commitment Push Model SOP Instance
StorageCommitmentPullModelSOPClassRetired = 68, // Storage Commitment Pull Model SOP Class
StorageCommitmentPullModelSOPInstanceRetired = 69, // Storage Commitment Pull Model SOP Instance
ProceduralEventLoggingSOPClass = 70, // Procedural Event Logging SOP Class
ProceduralEventLoggingSOPInstance = 71, // Procedural Event Logging SOP Instance
SubstanceAdministrationLoggingSOPClass = 72, // Substance Administration Logging SOP Class
SubstanceAdministrationLoggingSOPInstance = 73, // Substance Administration Logging SOP Instance
DICOMUIDRegistry = 74, // DICOM UID Registry
DICOMControlledTerminology = 75, // DICOM Controlled Terminology
AdultMouseAnatomyOntology = 76, // Adult Mouse Anatomy Ontology
UberonOntology = 77, // Uberon Ontology
IntegratedTaxonomicInformationSystemITISTaxonomicSerialNumberTSN = 78, // Integrated Taxonomic Information System (ITIS) Taxonomic Serial Number (TSN)
MouseGenomeInitiativeMGI = 79, // Mouse Genome Initiative (MGI)
PubChemCompoundCID = 80, // PubChem Compound CID
DublinCore = 81, // Dublin Core
NewYorkUniversityMelanomaClinicalCooperativeGroup = 82, // New York University Melanoma Clinical Cooperative Group
MayoClinicNonradiologicalImagesSpecificBodyStructureAnatomicalSurfaceRegionGuide = 83, // Mayo Clinic Non-radiological Images Specific Body Structure Anatomical Surface Region Guide
ImageBiomarkerStandardisationInitiative = 84, // Image Biomarker Standardisation Initiative
RadiomicsOntology = 85, // Radiomics Ontology
RadElement = 86, // RadElement
ICD11 = 87, // ICD-11
UnifiednumberingsystemUNSformetalsandalloys = 88, // Unified numbering system (UNS) for metals and alloys
ResearchResourceIdentification = 89, // Research Resource Identification
DICOMApplicationContextName = 90, // DICOM Application Context Name
DetachedPatientManagementSOPClassRetired = 91, // Detached Patient Management SOP Class
DetachedPatientManagementMetaSOPClassRetired = 92, // Detached Patient Management Meta SOP Class
DetachedVisitManagementSOPClassRetired = 93, // Detached Visit Management SOP Class
DetachedStudyManagementSOPClassRetired = 94, // Detached Study Management SOP Class
StudyComponentManagementSOPClassRetired = 95, // Study Component Management SOP Class
ModalityPerformedProcedureStepSOPClass = 96, // Modality Performed Procedure Step SOP Class
ModalityPerformedProcedureStepRetrieveSOPClass = 97, // Modality Performed Procedure Step Retrieve SOP Class
ModalityPerformedProcedureStepNotificationSOPClass = 98, // Modality Performed Procedure Step Notification SOP Class
DetachedResultsManagementSOPClassRetired = 99, // Detached Results Management SOP Class
DetachedResultsManagementMetaSOPClassRetired = 100, // Detached Results Management Meta SOP Class
DetachedStudyManagementMetaSOPClassRetired = 101, // Detached Study Management Meta SOP Class
DetachedInterpretationManagementSOPClassRetired = 102, // Detached Interpretation Management SOP Class
StorageServiceClass = 103, // Storage Service Class
BasicFilmSessionSOPClass = 104, // Basic Film Session SOP Class
BasicFilmBoxSOPClass = 105, // Basic Film Box SOP Class
BasicGrayscaleImageBoxSOPClass = 106, // Basic Grayscale Image Box SOP Class
BasicColorImageBoxSOPClass = 107, // Basic Color Image Box SOP Class
ReferencedImageBoxSOPClassRetired = 108, // Referenced Image Box SOP Class
BasicGrayscalePrintManagementMetaSOPClass = 109, // Basic Grayscale Print Management Meta SOP Class
ReferencedGrayscalePrintManagementMetaSOPClassRetired = 110, // Referenced Grayscale Print Management Meta SOP Class
PrintJobSOPClass = 111, // Print Job SOP Class
BasicAnnotationBoxSOPClass = 112, // Basic Annotation Box SOP Class
PrinterSOPClass = 113, // Printer SOP Class
PrinterConfigurationRetrievalSOPClass = 114, // Printer Configuration Retrieval SOP Class
PrinterSOPInstance = 115, // Printer SOP Instance
PrinterConfigurationRetrievalSOPInstance = 116, // Printer Configuration Retrieval SOP Instance
BasicColorPrintManagementMetaSOPClass = 117, // Basic Color Print Management Meta SOP Class
ReferencedColorPrintManagementMetaSOPClassRetired = 118, // Referenced Color Print Management Meta SOP Class
VOILUTBoxSOPClass = 119, // VOI LUT Box SOP Class
PresentationLUTSOPClass = 120, // Presentation LUT SOP Class
ImageOverlayBoxSOPClassRetired = 121, // Image Overlay Box SOP Class
BasicPrintImageOverlayBoxSOPClassRetired = 122, // Basic Print Image Overlay Box SOP Class
PrintQueueSOPInstanceRetired = 123, // Print Queue SOP Instance
PrintQueueManagementSOPClassRetired = 124, // Print Queue Management SOP Class
StoredPrintStorageSOPClassRetired = 125, // Stored Print Storage SOP Class
HardcopyGrayscaleImageStorageSOPClassRetired = 126, // Hardcopy Grayscale Image Storage SOP Class
HardcopyColorImageStorageSOPClassRetired = 127, // Hardcopy Color Image Storage SOP Class
PullPrintRequestSOPClassRetired = 128, // Pull Print Request SOP Class
PullStoredPrintManagementMetaSOPClassRetired = 129, // Pull Stored Print Management Meta SOP Class
MediaCreationManagementSOPClassUID = 130, // Media Creation Management SOP Class UID
DisplaySystemSOPClass = 131, // Display System SOP Class
DisplaySystemSOPInstance = 132, // Display System SOP Instance
ComputedRadiographyImageStorage = 133, // Computed Radiography Image Storage
DigitalXRayImageStorageForPresentation = 134, // Digital X-Ray Image Storage - For Presentation
DigitalXRayImageStorageForProcessing = 135, // Digital X-Ray Image Storage - For Processing
DigitalMammographyXRayImageStorageForPresentation = 136, // Digital Mammography X-Ray Image Storage - For Presentation
DigitalMammographyXRayImageStorageForProcessing = 137, // Digital Mammography X-Ray Image Storage - For Processing
DigitalIntraOralXRayImageStorageForPresentation = 138, // Digital Intra-Oral X-Ray Image Storage - For Presentation
DigitalIntraOralXRayImageStorageForProcessing = 139, // Digital Intra-Oral X-Ray Image Storage - For Processing
CTImageStorage = 140, // CT Image Storage
EnhancedCTImageStorage = 141, // Enhanced CT Image Storage
LegacyConvertedEnhancedCTImageStorage = 142, // Legacy Converted Enhanced CT Image Storage
UltrasoundMultiframeImageStorageRetired = 143, // Ultrasound Multi-frame Image Storage
UltrasoundMultiframeImageStorage = 144, // Ultrasound Multi-frame Image Storage
MRImageStorage = 145, // MR Image Storage
EnhancedMRImageStorage = 146, // Enhanced MR Image Storage
MRSpectroscopyStorage = 147, // MR Spectroscopy Storage
EnhancedMRColorImageStorage = 148, // Enhanced MR Color Image Storage
LegacyConvertedEnhancedMRImageStorage = 149, // Legacy Converted Enhanced MR Image Storage
NuclearMedicineImageStorageRetired = 150, // Nuclear Medicine Image Storage
UltrasoundImageStorageRetired = 151, // Ultrasound Image Storage
UltrasoundImageStorage = 152, // Ultrasound Image Storage
EnhancedUSVolumeStorage = 153, // Enhanced US Volume Storage
SecondaryCaptureImageStorage = 154, // Secondary Capture Image Storage
MultiframeSingleBitSecondaryCaptureImageStorage = 155, // Multi-frame Single Bit Secondary Capture Image Storage
MultiframeGrayscaleByteSecondaryCaptureImageStorage = 156, // Multi-frame Grayscale Byte Secondary Capture Image Storage
MultiframeGrayscaleWordSecondaryCaptureImageStorage = 157, // Multi-frame Grayscale Word Secondary Capture Image Storage
MultiframeTrueColorSecondaryCaptureImageStorage = 158, // Multi-frame True Color Secondary Capture Image Storage
StandaloneOverlayStorageRetired = 159, // Standalone Overlay Storage
StandaloneCurveStorageRetired = 160, // Standalone Curve Storage
WaveformStorageTrialRetired = 161, // Waveform Storage - Trial
ECG12leadWaveformStorage = 162, // 12-lead ECG Waveform Storage
GeneralECGWaveformStorage = 163, // General ECG Waveform Storage
AmbulatoryECGWaveformStorage = 164, // Ambulatory ECG Waveform Storage
HemodynamicWaveformStorage = 165, // Hemodynamic Waveform Storage
CardiacElectrophysiologyWaveformStorage = 166, // Cardiac Electrophysiology Waveform Storage
BasicVoiceAudioWaveformStorage = 167, // Basic Voice Audio Waveform Storage
GeneralAudioWaveformStorage = 168, // General Audio Waveform Storage
ArterialPulseWaveformStorage = 169, // Arterial Pulse Waveform Storage
RespiratoryWaveformStorage = 170, // Respiratory Waveform Storage
MultichannelRespiratoryWaveformStorage = 171, // Multi-channel Respiratory Waveform Storage
RoutineScalpElectroencephalogramWaveformStorage = 172, // Routine Scalp Electroencephalogram Waveform Storage
ElectromyogramWaveformStorage = 173, // Electromyogram Waveform Storage
ElectrooculogramWaveformStorage = 174, // Electrooculogram Waveform Storage
SleepElectroencephalogramWaveformStorage = 175, // Sleep Electroencephalogram Waveform Storage
BodyPositionWaveformStorage = 176, // Body Position Waveform Storage
StandaloneModalityLUTStorageRetired = 177, // Standalone Modality LUT Storage
StandaloneVOILUTStorageRetired = 178, // Standalone VOI LUT Storage
GrayscaleSoftcopyPresentationStateStorage = 179, // Grayscale Softcopy Presentation State Storage
ColorSoftcopyPresentationStateStorage = 180, // Color Softcopy Presentation State Storage
PseudoColorSoftcopyPresentationStateStorage = 181, // Pseudo-Color Softcopy Presentation State Storage
BlendingSoftcopyPresentationStateStorage = 182, // Blending Softcopy Presentation State Storage
XAXRFGrayscaleSoftcopyPresentationStateStorage = 183, // XA/XRF Grayscale Softcopy Presentation State Storage
GrayscalePlanarMPRVolumetricPresentationStateStorage = 184, // Grayscale Planar MPR Volumetric Presentation State Storage
CompositingPlanarMPRVolumetricPresentationStateStorage = 185, // Compositing Planar MPR Volumetric Presentation State Storage
AdvancedBlendingPresentationStateStorage = 186, // Advanced Blending Presentation State Storage
VolumeRenderingVolumetricPresentationStateStorage = 187, // Volume Rendering Volumetric Presentation State Storage
SegmentedVolumeRenderingVolumetricPresentationStateStorage = 188, // Segmented Volume Rendering Volumetric Presentation State Storage
MultipleVolumeRenderingVolumetricPresentationStateStorage = 189, // Multiple Volume Rendering Volumetric Presentation State Storage
XRayAngiographicImageStorage = 190, // X-Ray Angiographic Image Storage
EnhancedXAImageStorage = 191, // Enhanced XA Image Storage
XRayRadiofluoroscopicImageStorage = 192, // X-Ray Radiofluoroscopic Image Storage
EnhancedXRFImageStorage = 193, // Enhanced XRF Image Storage
XRayAngiographicBiPlaneImageStorageRetired = 194, // X-Ray Angiographic Bi-Plane Image Storage
Retired0 = 195, // 
XRay3DAngiographicImageStorage = 196, // X-Ray 3D Angiographic Image Storage
XRay3DCraniofacialImageStorage = 197, // X-Ray 3D Craniofacial Image Storage
BreastTomosynthesisImageStorage = 198, // Breast Tomosynthesis Image Storage
BreastProjectionXRayImageStorageForPresentation = 199, // Breast Projection X-Ray Image Storage - For Presentation
BreastProjectionXRayImageStorageForProcessing = 200, // Breast Projection X-Ray Image Storage - For Processing
IntravascularOpticalCoherenceTomographyImageStorageForPresentation = 201, // Intravascular Optical Coherence Tomography Image Storage - For Presentation
IntravascularOpticalCoherenceTomographyImageStorageForProcessing = 202, // Intravascular Optical Coherence Tomography Image Storage - For Processing
NuclearMedicineImageStorage = 203, // Nuclear Medicine Image Storage
ParametricMapStorage = 204, // Parametric Map Storage
Retired1 = 205, // 
RawDataStorage = 206, // Raw Data Storage
SpatialRegistrationStorage = 207, // Spatial Registration Storage
SpatialFiducialsStorage = 208, // Spatial Fiducials Storage
DeformableSpatialRegistrationStorage = 209, // Deformable Spatial Registration Storage
SegmentationStorage = 210, // Segmentation Storage
SurfaceSegmentationStorage = 211, // Surface Segmentation Storage
TractographyResultsStorage = 212, // Tractography Results Storage
RealWorldValueMappingStorage = 213, // Real World Value Mapping Storage
SurfaceScanMeshStorage = 214, // Surface Scan Mesh Storage
SurfaceScanPointCloudStorage = 215, // Surface Scan Point Cloud Storage
VLImageStorageTrialRetired = 216, // VL Image Storage - Trial
VLMultiframeImageStorageTrialRetired = 217, // VL Multi-frame Image Storage - Trial
VLEndoscopicImageStorage = 218, // VL Endoscopic Image Storage
VideoEndoscopicImageStorage = 219, // Video Endoscopic Image Storage
VLMicroscopicImageStorage = 220, // VL Microscopic Image Storage
VideoMicroscopicImageStorage = 221, // Video Microscopic Image Storage
VLSlideCoordinatesMicroscopicImageStorage = 222, // VL Slide-Coordinates Microscopic Image Storage
VLPhotographicImageStorage = 223, // VL Photographic Image Storage
VideoPhotographicImageStorage = 224, // Video Photographic Image Storage
OphthalmicPhotography8BitImageStorage = 225, // Ophthalmic Photography 8 Bit Image Storage
OphthalmicPhotography16BitImageStorage = 226, // Ophthalmic Photography 16 Bit Image Storage
StereometricRelationshipStorage = 227, // Stereometric Relationship Storage
OphthalmicTomographyImageStorage = 228, // Ophthalmic Tomography Image Storage
WideFieldOphthalmicPhotographyStereographicProjectionImageStorage = 229, // Wide Field Ophthalmic Photography Stereographic Projection Image Storage
WideFieldOphthalmicPhotography3DCoordinatesImageStorage = 230, // Wide Field Ophthalmic Photography 3D Coordinates Image Storage
OphthalmicOpticalCoherenceTomographyEnFaceImageStorage = 231, // Ophthalmic Optical Coherence Tomography En Face Image Storage
OphthalmicOpticalCoherenceTomographyBscanVolumeAnalysisStorage = 232, // Ophthalmic Optical Coherence Tomography B-scan Volume Analysis Storage
VLWholeSlideMicroscopyImageStorage = 233, // VL Whole Slide Microscopy Image Storage
DermoscopicPhotographyImageStorage = 234, // Dermoscopic Photography Image Storage
LensometryMeasurementsStorage = 235, // Lensometry Measurements Storage
AutorefractionMeasurementsStorage = 236, // Autorefraction Measurements Storage
KeratometryMeasurementsStorage = 237, // Keratometry Measurements Storage
SubjectiveRefractionMeasurementsStorage = 238, // Subjective Refraction Measurements Storage
VisualAcuityMeasurementsStorage = 239, // Visual Acuity Measurements Storage
SpectaclePrescriptionReportStorage = 240, // Spectacle Prescription Report Storage
OphthalmicAxialMeasurementsStorage = 241, // Ophthalmic Axial Measurements Storage
IntraocularLensCalculationsStorage = 242, // Intraocular Lens Calculations Storage
MacularGridThicknessandVolumeReportStorage = 243, // Macular Grid Thickness and Volume Report Storage
OphthalmicVisualFieldStaticPerimetryMeasurementsStorage = 244, // Ophthalmic Visual Field Static Perimetry Measurements Storage
OphthalmicThicknessMapStorage = 245, // Ophthalmic Thickness Map Storage
CornealTopographyMapStorage = 246, // Corneal Topography Map Storage
TextSRStorageTrialRetired = 247, // Text SR Storage - Trial
AudioSRStorageTrialRetired = 248, // Audio SR Storage - Trial
DetailSRStorageTrialRetired = 249, // Detail SR Storage - Trial
ComprehensiveSRStorageTrialRetired = 250, // Comprehensive SR Storage - Trial
BasicTextSRStorage = 251, // Basic Text SR Storage
EnhancedSRStorage = 252, // Enhanced SR Storage
ComprehensiveSRStorage = 253, // Comprehensive SR Storage
Comprehensive3DSRStorage = 254, // Comprehensive 3D SR Storage
ExtensibleSRStorage = 255, // Extensible SR Storage
ProcedureLogStorage = 256, // Procedure Log Storage
MammographyCADSRStorage = 257, // Mammography CAD SR Storage
KeyObjectSelectionDocumentStorage = 258, // Key Object Selection Document Storage
ChestCADSRStorage = 259, // Chest CAD SR Storage
XRayRadiationDoseSRStorage = 260, // X-Ray Radiation Dose SR Storage
RadiopharmaceuticalRadiationDoseSRStorage = 261, // Radiopharmaceutical Radiation Dose SR Storage
ColonCADSRStorage = 262, // Colon CAD SR Storage
ImplantationPlanSRStorage = 263, // Implantation Plan SR Storage
AcquisitionContextSRStorage = 264, // Acquisition Context SR Storage
SimplifiedAdultEchoSRStorage = 265, // Simplified Adult Echo SR Storage
PatientRadiationDoseSRStorage = 266, // Patient Radiation Dose SR Storage
PlannedImagingAgentAdministrationSRStorage = 267, // Planned Imaging Agent Administration SR Storage
PerformedImagingAgentAdministrationSRStorage = 268, // Performed Imaging Agent Administration SR Storage
EnhancedXRayRadiationDoseSRStorage = 269, // Enhanced X-Ray Radiation Dose SR Storage
ContentAssessmentResultsStorage = 270, // Content Assessment Results Storage
MicroscopyBulkSimpleAnnotationsStorage = 271, // Microscopy Bulk Simple Annotations Storage
EncapsulatedPDFStorage = 272, // Encapsulated PDF Storage
EncapsulatedCDAStorage = 273, // Encapsulated CDA Storage
EncapsulatedSTLStorage = 274, // Encapsulated STL Storage
EncapsulatedOBJStorage = 275, // Encapsulated OBJ Storage
EncapsulatedMTLStorage = 276, // Encapsulated MTL Storage
PositronEmissionTomographyImageStorage = 277, // Positron Emission Tomography Image Storage
LegacyConvertedEnhancedPETImageStorage = 278, // Legacy Converted Enhanced PET Image Storage
StandalonePETCurveStorageRetired = 279, // Standalone PET Curve Storage
EnhancedPETImageStorage = 280, // Enhanced PET Image Storage
BasicStructuredDisplayStorage = 281, // Basic Structured Display Storage
CTDefinedProcedureProtocolStorage = 282, // CT Defined Procedure Protocol Storage
CTPerformedProcedureProtocolStorage = 283, // CT Performed Procedure Protocol Storage
ProtocolApprovalStorage = 284, // Protocol Approval Storage
ProtocolApprovalInformationModelFIND = 285, // Protocol Approval Information Model - FIND
ProtocolApprovalInformationModelMOVE = 286, // Protocol Approval Information Model - MOVE
ProtocolApprovalInformationModelGET = 287, // Protocol Approval Information Model - GET
XADefinedProcedureProtocolStorage = 288, // XA Defined Procedure Protocol Storage
XAPerformedProcedureProtocolStorage = 289, // XA Performed Procedure Protocol Storage
InventoryStorage = 290, // Inventory Storage
InventoryFIND = 291, // Inventory - FIND
InventoryMOVE = 292, // Inventory - MOVE
InventoryGET = 293, // Inventory - GET
InventoryCreation = 294, // Inventory Creation
RepositoryQuery = 295, // Repository Query
StorageManagementSOPInstance = 296, // Storage Management SOP Instance
RTImageStorage = 297, // RT Image Storage
RTDoseStorage = 298, // RT Dose Storage
RTStructureSetStorage = 299, // RT Structure Set Storage
RTBeamsTreatmentRecordStorage = 300, // RT Beams Treatment Record Storage
RTPlanStorage = 301, // RT Plan Storage
RTBrachyTreatmentRecordStorage = 302, // RT Brachy Treatment Record Storage
RTTreatmentSummaryRecordStorage = 303, // RT Treatment Summary Record Storage
RTIonPlanStorage = 304, // RT Ion Plan Storage
RTIonBeamsTreatmentRecordStorage = 305, // RT Ion Beams Treatment Record Storage
RTPhysicianIntentStorage = 306, // RT Physician Intent Storage
RTSegmentAnnotationStorage = 307, // RT Segment Annotation Storage
RTRadiationSetStorage = 308, // RT Radiation Set Storage
CArmPhotonElectronRadiationStorage = 309, // C-Arm Photon-Electron Radiation Storage
TomotherapeuticRadiationStorage = 310, // Tomotherapeutic Radiation Storage
RoboticArmRadiationStorage = 311, // Robotic-Arm Radiation Storage
RTRadiationRecordSetStorage = 312, // RT Radiation Record Set Storage
RTRadiationSalvageRecordStorage = 313, // RT Radiation Salvage Record Storage
TomotherapeuticRadiationRecordStorage = 314, // Tomotherapeutic Radiation Record Storage
CArmPhotonElectronRadiationRecordStorage = 315, // C-Arm Photon-Electron Radiation Record Storage
RoboticRadiationRecordStorage = 316, // Robotic Radiation Record Storage
RTRadiationSetDeliveryInstructionStorage = 317, // RT Radiation Set Delivery Instruction Storage
RTTreatmentPreparationStorage = 318, // RT Treatment Preparation Storage
DICOSCTImageStorage = 319, // DICOS CT Image Storage
DICOSDigitalXRayImageStorageForPresentation = 320, // DICOS Digital X-Ray Image Storage - For Presentation
DICOSDigitalXRayImageStorageForProcessing = 321, // DICOS Digital X-Ray Image Storage - For Processing
DICOSThreatDetectionReportStorage = 322, // DICOS Threat Detection Report Storage
DICOS2DAITStorage = 323, // DICOS 2D AIT Storage
DICOS3DAITStorage = 324, // DICOS 3D AIT Storage
DICOSQuadrupoleResonanceQRStorage = 325, // DICOS Quadrupole Resonance (QR) Storage
EddyCurrentImageStorage = 326, // Eddy Current Image Storage
EddyCurrentMultiframeImageStorage = 327, // Eddy Current Multi-frame Image Storage
PatientRootQueryRetrieveInformationModelFIND = 328, // Patient Root Query/Retrieve Information Model - FIND
PatientRootQueryRetrieveInformationModelMOVE = 329, // Patient Root Query/Retrieve Information Model - MOVE
PatientRootQueryRetrieveInformationModelGET = 330, // Patient Root Query/Retrieve Information Model - GET
StudyRootQueryRetrieveInformationModelFIND = 331, // Study Root Query/Retrieve Information Model - FIND
StudyRootQueryRetrieveInformationModelMOVE = 332, // Study Root Query/Retrieve Information Model - MOVE
StudyRootQueryRetrieveInformationModelGET = 333, // Study Root Query/Retrieve Information Model - GET
PatientStudyOnlyQueryRetrieveInformationModelFINDRetired = 334, // Patient/Study Only Query/Retrieve Information Model - FIND
PatientStudyOnlyQueryRetrieveInformationModelMOVERetired = 335, // Patient/Study Only Query/Retrieve Information Model - MOVE
PatientStudyOnlyQueryRetrieveInformationModelGETRetired = 336, // Patient/Study Only Query/Retrieve Information Model - GET
CompositeInstanceRootRetrieveMOVE = 337, // Composite Instance Root Retrieve - MOVE
CompositeInstanceRootRetrieveGET = 338, // Composite Instance Root Retrieve - GET
CompositeInstanceRetrieveWithoutBulkDataGET = 339, // Composite Instance Retrieve Without Bulk Data - GET
DefinedProcedureProtocolInformationModelFIND = 340, // Defined Procedure Protocol Information Model - FIND
DefinedProcedureProtocolInformationModelMOVE = 341, // Defined Procedure Protocol Information Model - MOVE
DefinedProcedureProtocolInformationModelGET = 342, // Defined Procedure Protocol Information Model - GET
ModalityWorklistInformationModelFIND = 343, // Modality Worklist Information Model - FIND
GeneralPurposeWorklistManagementMetaSOPClassRetired = 344, // General Purpose Worklist Management Meta SOP Class
GeneralPurposeWorklistInformationModelFINDRetired = 345, // General Purpose Worklist Information Model - FIND
GeneralPurposeScheduledProcedureStepSOPClassRetired = 346, // General Purpose Scheduled Procedure Step SOP Class
GeneralPurposePerformedProcedureStepSOPClassRetired = 347, // General Purpose Performed Procedure Step SOP Class
InstanceAvailabilityNotificationSOPClass = 348, // Instance Availability Notification SOP Class
RTBeamsDeliveryInstructionStorageTrialRetired = 349, // RT Beams Delivery Instruction Storage - Trial
RTConventionalMachineVerificationTrialRetired = 350, // RT Conventional Machine Verification - Trial
RTIonMachineVerificationTrialRetired = 351, // RT Ion Machine Verification - Trial
UnifiedWorklistandProcedureStepServiceClassTrialRetired = 352, // Unified Worklist and Procedure Step Service Class - Trial
UnifiedProcedureStepPushSOPClassTrialRetired = 353, // Unified Procedure Step - Push SOP Class - Trial
UnifiedProcedureStepWatchSOPClassTrialRetired = 354, // Unified Procedure Step - Watch SOP Class - Trial
UnifiedProcedureStepPullSOPClassTrialRetired = 355, // Unified Procedure Step - Pull SOP Class - Trial
UnifiedProcedureStepEventSOPClassTrialRetired = 356, // Unified Procedure Step - Event SOP Class - Trial
UPSGlobalSubscriptionSOPInstance = 357, // UPS Global Subscription SOP Instance
UPSFilteredGlobalSubscriptionSOPInstance = 358, // UPS Filtered Global Subscription SOP Instance
UnifiedWorklistandProcedureStepServiceClass = 359, // Unified Worklist and Procedure Step Service Class
UnifiedProcedureStepPushSOPClass = 360, // Unified Procedure Step - Push SOP Class
UnifiedProcedureStepWatchSOPClass = 361, // Unified Procedure Step - Watch SOP Class
UnifiedProcedureStepPullSOPClass = 362, // Unified Procedure Step - Pull SOP Class
UnifiedProcedureStepEventSOPClass = 363, // Unified Procedure Step - Event SOP Class
UnifiedProcedureStepQuerySOPClass = 364, // Unified Procedure Step - Query SOP Class
RTBeamsDeliveryInstructionStorage = 365, // RT Beams Delivery Instruction Storage
RTConventionalMachineVerification = 366, // RT Conventional Machine Verification
RTIonMachineVerification = 367, // RT Ion Machine Verification
RTBrachyApplicationSetupDeliveryInstructionStorage = 368, // RT Brachy Application Setup Delivery Instruction Storage
GeneralRelevantPatientInformationQuery = 369, // General Relevant Patient Information Query
BreastImagingRelevantPatientInformationQuery = 370, // Breast Imaging Relevant Patient Information Query
CardiacRelevantPatientInformationQuery = 371, // Cardiac Relevant Patient Information Query
HangingProtocolStorage = 372, // Hanging Protocol Storage
HangingProtocolInformationModelFIND = 373, // Hanging Protocol Information Model - FIND
HangingProtocolInformationModelMOVE = 374, // Hanging Protocol Information Model - MOVE
HangingProtocolInformationModelGET = 375, // Hanging Protocol Information Model - GET
ColorPaletteStorage = 376, // Color Palette Storage
ColorPaletteQueryRetrieveInformationModelFIND = 377, // Color Palette Query/Retrieve Information Model - FIND
ColorPaletteQueryRetrieveInformationModelMOVE = 378, // Color Palette Query/Retrieve Information Model - MOVE
ColorPaletteQueryRetrieveInformationModelGET = 379, // Color Palette Query/Retrieve Information Model - GET
ProductCharacteristicsQuerySOPClass = 380, // Product Characteristics Query SOP Class
SubstanceApprovalQuerySOPClass = 381, // Substance Approval Query SOP Class
GenericImplantTemplateStorage = 382, // Generic Implant Template Storage
GenericImplantTemplateInformationModelFIND = 383, // Generic Implant Template Information Model - FIND
GenericImplantTemplateInformationModelMOVE = 384, // Generic Implant Template Information Model - MOVE
GenericImplantTemplateInformationModelGET = 385, // Generic Implant Template Information Model - GET
ImplantAssemblyTemplateStorage = 386, // Implant Assembly Template Storage
ImplantAssemblyTemplateInformationModelFIND = 387, // Implant Assembly Template Information Model - FIND
ImplantAssemblyTemplateInformationModelMOVE = 388, // Implant Assembly Template Information Model - MOVE
ImplantAssemblyTemplateInformationModelGET = 389, // Implant Assembly Template Information Model - GET
ImplantTemplateGroupStorage = 390, // Implant Template Group Storage
ImplantTemplateGroupInformationModelFIND = 391, // Implant Template Group Information Model - FIND
ImplantTemplateGroupInformationModelMOVE = 392, // Implant Template Group Information Model - MOVE
ImplantTemplateGroupInformationModelGET = 393, // Implant Template Group Information Model - GET
NativeDICOMModel = 394, // Native DICOM Model
AbstractMultiDimensionalImageModel = 395, // Abstract Multi-Dimensional Image Model
DICOMContentMappingResource = 396, // DICOM Content Mapping Resource
VideoEndoscopicImageRealTimeCommunication = 397, // Video Endoscopic Image Real-Time Communication
VideoPhotographicImageRealTimeCommunication = 398, // Video Photographic Image Real-Time Communication
AudioWaveformRealTimeCommunication = 399, // Audio Waveform Real-Time Communication
RenditionSelectionDocumentRealTimeCommunication = 400, // Rendition Selection Document Real-Time Communication
dicomDeviceName = 401, // dicomDeviceName
dicomDescription = 402, // dicomDescription
dicomManufacturer = 403, // dicomManufacturer
dicomManufacturerModelName = 404, // dicomManufacturerModelName
dicomSoftwareVersion = 405, // dicomSoftwareVersion
dicomVendorData = 406, // dicomVendorData
dicomAETitle = 407, // dicomAETitle
dicomNetworkConnectionReference = 408, // dicomNetworkConnectionReference
dicomApplicationCluster = 409, // dicomApplicationCluster
dicomAssociationInitiator = 410, // dicomAssociationInitiator
dicomAssociationAcceptor = 411, // dicomAssociationAcceptor
dicomHostname = 412, // dicomHostname
dicomPort = 413, // dicomPort
dicomSOPClass = 414, // dicomSOPClass
dicomTransferRole = 415, // dicomTransferRole
dicomTransferSyntax = 416, // dicomTransferSyntax
dicomPrimaryDeviceType = 417, // dicomPrimaryDeviceType
dicomRelatedDeviceReference = 418, // dicomRelatedDeviceReference
dicomPreferredCalledAETitle = 419, // dicomPreferredCalledAETitle
dicomTLSCyphersuite = 420, // dicomTLSCyphersuite
dicomAuthorizedNodeCertificateReference = 421, // dicomAuthorizedNodeCertificateReference
dicomThisNodeCertificateReference = 422, // dicomThisNodeCertificateReference
dicomInstalled = 423, // dicomInstalled
dicomStationName = 424, // dicomStationName
dicomDeviceSerialNumber = 425, // dicomDeviceSerialNumber
dicomInstitutionName = 426, // dicomInstitutionName
dicomInstitutionAddress = 427, // dicomInstitutionAddress
dicomInstitutionDepartmentName = 428, // dicomInstitutionDepartmentName
dicomIssuerOfPatientID = 429, // dicomIssuerOfPatientID
dicomPreferredCallingAETitle = 430, // dicomPreferredCallingAETitle
dicomSupportedCharacterSet = 431, // dicomSupportedCharacterSet
dicomConfigurationRoot = 432, // dicomConfigurationRoot
dicomDevicesRoot = 433, // dicomDevicesRoot
dicomUniqueAETitlesRegistryRoot = 434, // dicomUniqueAETitlesRegistryRoot
dicomDevice = 435, // dicomDevice
dicomNetworkAE = 436, // dicomNetworkAE
dicomNetworkConnection = 437, // dicomNetworkConnection
dicomUniqueAETitle = 438, // dicomUniqueAETitle
dicomTransferCapability = 439, // dicomTransferCapability
UniversalCoordinatedTime = 440, // Universal Coordinated Time
TalairachBrainAtlasFrameofReference = 441, // Talairach Brain Atlas Frame of Reference
SPM2T1FrameofReference = 442, // SPM2 T1 Frame of Reference
SPM2T2FrameofReference = 443, // SPM2 T2 Frame of Reference
SPM2PDFrameofReference = 444, // SPM2 PD Frame of Reference
SPM2EPIFrameofReference = 445, // SPM2 EPI Frame of Reference
SPM2FILT1FrameofReference = 446, // SPM2 FIL T1 Frame of Reference
SPM2PETFrameofReference = 447, // SPM2 PET Frame of Reference
SPM2TRANSMFrameofReference = 448, // SPM2 TRANSM Frame of Reference
SPM2SPECTFrameofReference = 449, // SPM2 SPECT Frame of Reference
SPM2GRAYFrameofReference = 450, // SPM2 GRAY Frame of Reference
SPM2WHITEFrameofReference = 451, // SPM2 WHITE Frame of Reference
SPM2CSFFrameofReference = 452, // SPM2 CSF Frame of Reference
SPM2BRAINMASKFrameofReference = 453, // SPM2 BRAINMASK Frame of Reference
SPM2AVG305T1FrameofReference = 454, // SPM2 AVG305T1 Frame of Reference
SPM2AVG152T1FrameofReference = 455, // SPM2 AVG152T1 Frame of Reference
SPM2AVG152T2FrameofReference = 456, // SPM2 AVG152T2 Frame of Reference
SPM2AVG152PDFrameofReference = 457, // SPM2 AVG152PD Frame of Reference
SPM2SINGLESUBJT1FrameofReference = 458, // SPM2 SINGLESUBJT1 Frame of Reference
ICBM452T1FrameofReference = 459, // ICBM 452 T1 Frame of Reference
ICBMSingleSubjectMRIFrameofReference = 460, // ICBM Single Subject MRI Frame of Reference
IEC61217FixedCoordinateSystemFrameofReference = 461, // IEC 61217 Fixed Coordinate System Frame of Reference
StandardRoboticArmCoordinateSystemFrameofReference = 462, // Standard Robotic-Arm Coordinate System Frame of Reference
IEC61217TableTopCoordinateSystemFrameofReference = 463, // IEC 61217 Table Top Coordinate System Frame of Reference
SRI24FrameofReference = 464, // SRI24 Frame of Reference
Colin27FrameofReference = 465, // Colin27 Frame of Reference
LPBA40AIRFrameofReference = 466, // LPBA40/AIR Frame of Reference
LPBA40FLIRTFrameofReference = 467, // LPBA40/FLIRT Frame of Reference
LPBA40SPM5FrameofReference = 468, // LPBA40/SPM5 Frame of Reference
} TSName;


  typedef const char* const (*TransferSyntaxStringsType)[2];
  static TransferSyntaxStringsType GetTransferSyntaxStrings();
  static const char * const *GetTransferSyntaxString(unsigned int ts);
  static unsigned int GetNumberOfTransferSyntaxStrings();


  // TODO: Because I would like a dual signature for TSType and TSName, C++ won't let me do it...
  static const char* GetUIDString(/*TSType*/ unsigned int ts);
  static const char* GetUIDName(/*TSType*/ unsigned int ts);

  /// Initialize object from a string (a uid number)
  /// return false on error, and internal state is set to 0
  bool SetFromUID(const char *str);

  /// When object is Initialize function return the well known name associated with uid
  /// return NULL when not initialized
  const char *GetName() const;

  /// When object is Initialize function return the uid
  /// return NULL when not initialized
  const char *GetString() const;

  operator TSType () const { return TSField; }
  UIDs() = default;

private:
  TSType TSField;
};
//-----------------------------------------------------------------------------
inline std::ostream &operator<<(std::ostream &_os, const UIDs &uid)
{
  _os << uid.GetString() << " -> " << uid.GetName();
  return _os;

}

} // end namespace gdcm

#endif //GDCMUIDS_H
